#!/bin/bash
set -e
PREFIX="${PREFIX:-/usr/local}"
cp -r bin/* "${PREFIX}/bin/"
mkdir -p "${PREFIX}/share/cvm-cli"
cp -r share/cvm-cli/* "${PREFIX}/share/cvm-cli/"
echo "✅ cvm-cli installed to ${PREFIX}"
