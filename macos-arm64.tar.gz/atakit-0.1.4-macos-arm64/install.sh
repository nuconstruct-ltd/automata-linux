#!/bin/bash
set -e
PREFIX="${PREFIX:-/usr/local}"
cp -r bin/* "${PREFIX}/bin/"
mkdir -p "${PREFIX}/share/atakit"
cp -r share/atakit/* "${PREFIX}/share/atakit/"
echo "✅ atakit installed to ${PREFIX}"
